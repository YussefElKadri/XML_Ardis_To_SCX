﻿using System;
using System.IO;
using System.Linq;
using System.Xml.Linq;

class Program
{
	static void Main(string[] args)
	{
		string inputFilePath = @"C:\Users\User\Documents\Arquivos Yussef\CSharp\XML_Ardis_To_SCX\XML_Ardis_To_SCX\XML_Ardis_To_SCX\bin\Debug\TopXMLToScx.xml"; // Update with your XML file path
		string outputDirectory = @"C:\Users\User\Documents\Arquivos Yussef\CSharp\XML_Ardis_To_SCX\XML_Ardis_To_SCX\XML_Ardis_To_SCX\bin\Debug"; // Directory to save the text files


		if (!Directory.Exists(outputDirectory))
		{
			Directory.CreateDirectory(outputDirectory);
		}

		XDocument doc = XDocument.Load(inputFilePath);
		var parts = doc.Descendants("Part");

		int partCounter = 1;
		foreach (var part in parts)
		{
			string partID = part.Element("PartRef")?.Value;
			string partName = part.Element("PartExt15")?.Value;
			string partLengthStr = part.Element("PartL")?.Value;
			string partWidthStr = part.Element("PartW")?.Value;
			string partThickness = part.Element("PartExt13")?.Value;
			double partLength = double.Parse(partLengthStr);
			double partWidth = double.Parse(partWidthStr);
			double zValue = double.Parse(partThickness) / 2;

			using (StreamWriter writer = new StreamWriter(Path.Combine(outputDirectory, $"{partID}.scx")))
			{
				// Write the new header section
				writer.WriteLine("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
				writer.WriteLine("<Root Cad=\"BuiltInCad\" version=\"2.0\">");
				writer.WriteLine("  <Project>");
				writer.WriteLine("    <Panels>");
				writer.WriteLine($"      <Panel IsProduce=\"true\" ID=\"{partID}\" Name=\"{partName}\" Length=\"{partLength}\" Width=\"{partWidth}\" Thickness=\"{partThickness}\" MachiningPoint=\"1\">");

				// Write outline points with updated indentation format
				writer.WriteLine("        <Outline>");
				writer.WriteLine($"          <Point X=\"{partLength}\" Y=\"{partWidth}\" />");
				writer.WriteLine($"          <Point X=\"0\" Y=\"{partWidth}\" />");
				writer.WriteLine("          <Point X=\"0\" Y=\"0\" />");
				writer.WriteLine($"          <Point X=\"{partLength}\" Y=\"0\" />");
				writer.WriteLine("        </Outline>");
				writer.WriteLine("        <Machines>");

				// Group by Function Name
				var drawElements = part.Descendants("Draw").GroupBy(d => d.Element("FUNCTNAME")?.Value);

				foreach (var group in drawElements)
				{
					foreach (var draw in group)
					{
						if (group.Key == "DRILL")
						{
							double x = double.Parse(draw.Element("X")?.Value ?? "0");
							double y = double.Parse(draw.Element("Y")?.Value ?? "0");
							double diameter = double.Parse(draw.Element("RADIUS")?.Value ?? "0") * 2;
							double depth = double.Parse(draw.Element("Z2")?.Value ?? "0");
							int side = int.Parse(draw.Element("SIDE")?.Value ?? "0");
							int type = (side == 0 || side == 5) ? 2 : 1;
							int face;

							switch (side)
							{
								case 0: face = 5; break;
								case 1: face = 1; break;
								case 2: face = 3; break;
								case 3: face = 2; break;
								case 4: face = 4; break;
								case 5: face = 6; break;
								default: face = 5; break;
							}

							if (side == 5)
							{
								x = partLength - x;
							}

							if (type == 1)
							{
								switch (face)
								{
									case 1:
										y = partWidth;
										x = partLength - x;
										break;
									case 2:
										y = 0;
										break;
									case 3:
										y = x;
										x = partLength;
										break;
									case 4:
										y = partWidth - x;
										x = 0;
										break;
								}

								writer.WriteLine($"          <Machining Type=\"{type}\" IsGenCode=\"2\" Face=\"{face}\" X=\"{x}\" Y=\"{y}\" Z=\"{zValue}\" Diameter=\"{diameter}\" Depth=\"{depth}\" />");
							}
							else
							{
								writer.WriteLine($"          <Machining Type=\"{type}\" IsGenCode=\"2\" Face=\"{face}\" X=\"{x}\" Y=\"{y}\" Diameter=\"{diameter}\" Depth=\"{depth}\" />");
							}
						}
						else
						{
							writer.WriteLine(
								$"TOOL: {draw.Element("TOOL")?.Value} | " +
								$"SIDE: {draw.Element("SIDE")?.Value} | " +
								$"X: {draw.Element("X")?.Value} | " +
								$"Y: {draw.Element("Y")?.Value} | " +
								$"LENGTH: {draw.Element("LENGTH")?.Value} | " +
								$"WIDTH: {draw.Element("WIDTH")?.Value} | " +
								$"RADIUS: {draw.Element("RADIUS")?.Value} | " +
								$"Z2: {draw.Element("Z2")?.Value} | " +
								$"MACHPARAM: {draw.Element("MACHPARAM")?.Value} | " +
								$"OPDIM: {draw.Element("OPDIM")?.Value} | " +
								$"OPSIDE: {draw.Element("OPSIDE")?.Value} | " +
								$"ID: {draw.Element("ID")?.Value} | " +
								$"SEQ: {draw.Element("SEQ")?.Value} | " +
								$"OPTYPE: {draw.Element("OPTYPE")?.Value} | " +
								$"THICK: {draw.Element("THICK")?.Value}"
							);
						}
					}
				}

				// Close the Machines tag and add EdgeGroup
				writer.WriteLine("        </Machines>");
				writer.WriteLine("        <EdgeGroup X1=\"0\" Y1=\"0\">");
				writer.WriteLine("          <Edge Face=\"2\" Thickness=\"0\" Pre_Milling=\"0\" X=\"0\" Y=\"0\" CentralAngle=\"0\" />");
				writer.WriteLine("          <Edge Face=\"1\" Thickness=\"0\" Pre_Milling=\"0\" X=\"0\" Y=\"0\" CentralAngle=\"0\" />");
				writer.WriteLine("          <Edge Face=\"4\" Thickness=\"0\" Pre_Milling=\"0\" X=\"0\" Y=\"0\" CentralAngle=\"0\" />");
				writer.WriteLine("          <Edge Face=\"3\" Thickness=\"0\" Pre_Milling=\"0\" X=\"0\" Y=\"0\" CentralAngle=\"0\" />");
				writer.WriteLine("        </EdgeGroup>");
				writer.WriteLine("      </Panel>");
				writer.WriteLine("    </Panels>");
				writer.WriteLine("  </Project>");
				writer.WriteLine("</Root>");
			}

			partCounter++;
		}

		Console.WriteLine("Parts have been successfully written to SCX files.");
	}
}
