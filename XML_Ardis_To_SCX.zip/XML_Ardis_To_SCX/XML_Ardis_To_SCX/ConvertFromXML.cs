﻿using System;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Xml.Linq;

class ConvertFromXML
{
	public string ConvertFromXMLSCX(string path)
	{
		string pasta = Directory.GetCurrentDirectory();
		string[] listaArquivosXML = Directory.GetFiles(pasta, "*.xml");
		string outputDirectory = pasta + @"\SCX"; //Pasta de escrita

		foreach (var inputFilePath in listaArquivosXML)
		{
			if (!Directory.Exists(outputDirectory))
			{
				Directory.CreateDirectory(outputDirectory);
			}

			XDocument doc = XDocument.Load(inputFilePath);
			var parts = doc.Descendants("Part");

			foreach (var part in parts)
			{
				string partID = part.Element("PartRef")?.Value;
				string partName = part.Element("PartExt15")?.Value;
				string partLengthStr = part.Element("PartL")?.Value;
				string partWidthStr = part.Element("PartW")?.Value;
				string partThickness = part.Element("PartExt13")?.Value;
				double partLength = Math.Round(double.Parse(partLengthStr), 2);
				double partWidth = Math.Round(double.Parse(partWidthStr), 2);
				double partThicknessValue = double.Parse(partThickness);
				double zValue = partThicknessValue / 2;

				using (StreamWriter writer = new StreamWriter(Path.Combine(outputDirectory, $"{partID}.scx")))
				{
					// Write the new header section
					writer.WriteLine("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
					writer.WriteLine("<Root Cad=\"BuiltInCad\" version=\"2.0\">");
					writer.WriteLine("  <Project>");
					writer.WriteLine("    <Panels>");
					writer.WriteLine($"      <Panel IsProduce=\"true\" ID=\"{partID}\" Name=\"{partName}\" Length=\"{partLength}\" Width=\"{partWidth}\" Thickness=\"{partThickness}\" MachiningPoint=\"1\">");

					// Write outline points with updated indentation format
					writer.WriteLine("        <Outline>");
					writer.WriteLine($"          <Point X=\"{partLength}\" Y=\"{partWidth}\" />");
					writer.WriteLine($"          <Point X=\"0\" Y=\"{partWidth}\" />");
					writer.WriteLine("          <Point X=\"0\" Y=\"0\" />");
					writer.WriteLine($"          <Point X=\"{partLength}\" Y=\"0\" />");
					writer.WriteLine("        </Outline>");
					writer.WriteLine("        <Machines>");

					// Group by Function Name
					var drawElements = part.Descendants("Draw").GroupBy(d => d.Element("FUNCTNAME")?.Value);

					foreach (var group in drawElements)
					{
						foreach (var draw in group)
						{
							if (group.Key == "DRILL")
							{
								double x = Math.Round(double.Parse(draw.Element("X")?.Value ?? "0"), 2);
								double y = Math.Round(double.Parse(draw.Element("Y")?.Value ?? "0"), 2);
								double diameter = Math.Round(double.Parse(draw.Element("RADIUS")?.Value ?? "0") * 2, 2);
								double depth = Math.Round(double.Parse(draw.Element("Z2")?.Value ?? "0"), 2);
								int side = int.Parse(draw.Element("SIDE")?.Value ?? "0");
								int type = (side == 0 || side == 5) ? 2 : 1;
								int face;

								switch (side)
								{
									case 0: face = 5; break;
									case 1: face = 1; break;
									case 2: face = 3; break;
									case 3: face = 2; break;
									case 4: face = 4; break;
									case 5: face = 6; break;
									default: face = 5; break;
								}

								if (side == 5)
								{
									x = partLength - x;
								}

								if (type == 1)
								{
									switch (face)
									{
										case 1:
											double temp = y;
											y = partWidth;
											depth = temp;
											x = partLength - x;
											break;
										case 2:
											y = 0;
											break;
										case 3:
											y = x;
											x = partLength;
											break;
										case 4:
											y = partWidth - x;
											x = 0;
											break;
									}

									double zValueTopo = Math.Round(double.Parse(draw.Element("Y")?.Value ?? "0"), 2);
									writer.WriteLine($"          <Machining Type=\"{type}\" IsGenCode=\"2\" Face=\"{face}\" X=\"{x}\" Y=\"{y}\" Z=\"{zValueTopo}\" Diameter=\"{diameter}\" Depth=\"{depth}\" />");
								}
								else
								{
									if (double.Parse(draw.Element("Z2")?.Value) >= double.Parse(partThickness))
									{
										writer.WriteLine($"          <Machining Type=\"{type}\" IsGenCode=\"2\" Face=\"{5}\" X=\"{x}\" Y=\"{y}\" Diameter=\"{diameter}\" Depth=\"{depth / 2}\" />");
										writer.WriteLine($"          <Machining Type=\"{type}\" IsGenCode=\"2\" Face=\"{6}\" X=\"{x}\" Y=\"{y}\" Diameter=\"{diameter}\" Depth=\"{depth / 2}\" />");
									}
									else
									{
										writer.WriteLine($"          <Machining Type=\"{type}\" IsGenCode=\"2\" Face=\"{face}\" X=\"{x}\" Y=\"{y}\" Diameter=\"{diameter}\" Depth=\"{depth}\" />");
									}
								}
							}
							else if (group.Key == "LINE" && draw.Element("TOOL")?.Value == "\"SAW\"" && (draw.Element("X")?.Value == draw.Element("LENGTH")?.Value) || draw.Element("Y")?.Value == draw.Element("WIDTH")?.Value)
							{
								double x = Math.Round(double.Parse(draw.Element("X")?.Value ?? "0"), 2);
								double y = Math.Round(double.Parse(draw.Element("Y")?.Value ?? "0"), 2);
								double depth = Math.Round(double.Parse(draw.Element("Z2")?.Value ?? "0"), 2);
								double width = Math.Round(double.Parse(draw.Element("THICK")?.Value ?? "0"), 2);
								double endX = Math.Round(double.Parse(draw.Element("LENGTH")?.Value ?? "0"), 2);

								// Use the same face logic as drills
								int side = int.Parse(draw.Element("SIDE")?.Value ?? "0");
								int face;

								switch (side)
								{
									case 0: face = 5; break;
									case 1: face = 1; break;
									case 2: face = 3; break;
									case 3: face = 2; break;
									case 4: face = 4; break;
									case 5: face = 6; break;
									default: face = 5; break;
								}

								if (face == 1) // Side 1 line saw
								{
									double tempZ = y;
									y = partWidth;
									writer.WriteLine($"          <Machining Type=\"4\" IsGenCode=\"2\" Face=\"{face}\" X=\"{partLength - x}\" Y=\"{y}\" Z=\"{tempZ}\" EndX=\"{partLength - endX}\" EndY=\"{y}\" EndZ=\"{tempZ}\" Depth=\"{depth}\" Width=\"{width}\" ToolOffset=\"中\" />");
								}
								else if (face == 2) // Side 2 line saw
								{
									double tempZ = y;
									y = 0;
									writer.WriteLine($"          <Machining Type=\"4\" IsGenCode=\"2\" Face=\"{face}\" X=\"{x}\" Y=\"{y}\" Z=\"{tempZ}\" EndX=\"{endX}\" EndY=\"{y}\" EndZ=\"{tempZ}\" Depth=\"{depth}\" Width=\"{width}\" ToolOffset=\"中\" />");
								}
								//else if (face == 3) // Side 3 line saw**
								//{
								//	double tempZ = y;
								//	y = 0;
								//	writer.WriteLine($"          <Machining Type=\"4\" IsGenCode=\"2\" Face=\"{face}\" X=\"{x}\" Y=\"{y}\" Z=\"{tempZ}\" EndX=\"{endX}\" EndY=\"{y}\" EndZ=\"{tempZ}\" Depth=\"{depth}\" Width=\"{width}\" ToolOffset=\"中\" />");
								//}
								//else if (face == 4) // Side 4 line saw**
								//{
								//	double tempZ = y;
								//	y = 0;
								//	writer.WriteLine($"          <Machining Type=\"4\" IsGenCode=\"2\" Face=\"{face}\" X=\"{x}\" Y=\"{y}\" Z=\"{tempZ}\" EndX=\"{endX}\" EndY=\"{y}\" EndZ=\"{tempZ}\" Depth=\"{depth}\" Width=\"{width}\" ToolOffset=\"中\" />");
								//}
								else if (face == 5)
								{
									if (draw.Element("X")?.Value == draw.Element("LENGTH")?.Value) // Vertical line saw
									{
										double endY = Math.Round(double.Parse(draw.Element("WIDTH")?.Value ?? "0"), 2);
										writer.WriteLine($"          <Machining Type=\"4\" IsGenCode=\"2\" Face=\"{face}\" X=\"{x}\" Y=\"{y}\" Z=\"{partThicknessValue}\" EndX=\"{x}\" EndY=\"{endY}\" EndZ=\"{partThicknessValue}\" Depth=\"{depth}\" Width=\"{width}\" ToolOffset=\"中\" />");
									}
									else if (draw.Element("Y")?.Value == draw.Element("WIDTH")?.Value)// Horizontal line saw
									{
										writer.WriteLine($"          <Machining Type=\"4\" IsGenCode=\"2\" Face=\"{face}\" X=\"{x}\" Y=\"{y}\" Z=\"{partThicknessValue}\" EndX=\"{endX}\" EndY=\"{y}\" EndZ=\"{partThicknessValue}\" Depth=\"{depth}\" Width=\"{width}\" ToolOffset=\"中\" />");
									}
								}
								else if (face == 6)
								{
									if (draw.Element("X")?.Value == draw.Element("LENGTH")?.Value) // Vertical line saw
									{
										double endY = Math.Round(double.Parse(draw.Element("WIDTH")?.Value ?? "0"), 2);
										writer.WriteLine($"          <Machining Type=\"4\" IsGenCode=\"2\" Face=\"{face}\" X=\"{partLength - x}\" Y=\"{y}\" Z=\"{partThicknessValue}\" EndX=\"{partLength - x}\" EndY=\"{endY}\" EndZ=\"{partThicknessValue}\" Depth=\"{depth}\" Width=\"{width}\" ToolOffset=\"中\" />");
									}
									else if (draw.Element("Y")?.Value == draw.Element("WIDTH")?.Value)// Horizontal line saw
									{
										writer.WriteLine($"          <Machining Type=\"4\" IsGenCode=\"2\" Face=\"{face}\" X=\"{partLength - x}\" Y=\"{y}\" Z=\"{partThicknessValue}\" EndX=\"{partLength - endX}\" EndY=\"{y}\" EndZ=\"{partThicknessValue}\" Depth=\"{depth}\" Width=\"{width}\" ToolOffset=\"中\" />");
									}
								}
							}
						}
					}

					// Close the Machines tag and add EdgeGroup
					writer.WriteLine("        </Machines>");
					writer.WriteLine("        <EdgeGroup X1=\"0\" Y1=\"0\">");
					writer.WriteLine("          <Edge Face=\"2\" Thickness=\"0\" Pre_Milling=\"0\" X=\"0\" Y=\"0\" CentralAngle=\"0\" />");
					writer.WriteLine("          <Edge Face=\"1\" Thickness=\"0\" Pre_Milling=\"0\" X=\"0\" Y=\"0\" CentralAngle=\"0\" />");
					writer.WriteLine("          <Edge Face=\"4\" Thickness=\"0\" Pre_Milling=\"0\" X=\"0\" Y=\"0\" CentralAngle=\"0\" />");
					writer.WriteLine("          <Edge Face=\"3\" Thickness=\"0\" Pre_Milling=\"0\" X=\"0\" Y=\"0\" CentralAngle=\"0\" />");
					writer.WriteLine("        </EdgeGroup>");
					writer.WriteLine("      </Panel>");
					writer.WriteLine("    </Panels>");
					writer.WriteLine("  </Project>");
					writer.WriteLine("</Root>");
				}
			}

			Console.WriteLine("Peças geradas com sucesso, verifique a pasta!");
		}

		return path;
	}
}
